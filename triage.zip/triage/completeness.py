"""Completeness check: does a ticket carry the details the desk needs to work it?

Owner rule, 16 Sep 2026. Every ticket must identify a COMPANY and a CENTRE and
have a SCREENSHOT. Payment tickets must also carry the card's first 6 and last 4
digits; invoicing tickets must carry invoice numbers.

    from completeness import check
    check(short_desc, description, category)   # -> list of missing items

WHAT THIS CANNOT SEE. The daily export carries twelve columns and none of them is
an attachment field, so a screenshot is only detectable when the TEXT mentions
one. A ticket with a screenshot attached and no sentence about it looks exactly
like a ticket with none. Screenshot is therefore returned as a separate, weaker
signal and must not be the sole grounds for a cancellation.
"""
import re


def _c(p):
    return re.compile(p, re.I)


# --- company: a name, an account number, or a numbered reference to either
COMPANY = [
    _c(r"\b(?:company|account|customer|client)\s*(?:name|id|number|no|ref|#)\s*[:\-#]"),
    _c(r"\bcompany\s*[:\-]"),
    _c(r"\baccount\s*[:\-]\s*\w"),
    _c(r"\btitan\s*(?:id|ref(?:erence)?)\s*[:\-#]?\s*\d{5,}"),
    _c(r"\b\d{7,9}\s*[-–—]\s*[A-Za-z]"),      # 16695291 - The Westerman Foundation
    _c(r"\bac\s*[-–—:]\s*\d{6,}"),            # Ac - 17306395
    _c(r"\(\s*\d{7,9}\s*\)"),                            # (16610554)
    _c(r"\baccount\s+\d{6,}"),                           # for account 14302580, Lex Artia
    _c(r"\b\d{6,9}\s*[,:]\s*[A-Z]"),                     # 12883405 : Fahrenheit
    _c(r"\bfor\s+(?:the\s+)?(?:client|customer|company)\s+[A-Z]"),
]

# --- centre: named or numbered
CENTRE = [
    _c(r"\bcent(?:re|er)\s*(?:name|number|no|#)?\s*[:\-#/]\s*\S"),
    _c(r"\bcent(?:re|er)\s+\d{3,5}\b"),
    _c(r"\bcentre?\s*(?:nr|num)\.?\s*\d+"),
    _c(r"\b(?:regus|spaces|hq|signature)\s+[\w'’\-]+"),
    _c(r"\bcent(?:re|er)\s*#\s*\d+"),
    _c(r"[\w'’\-]+\s+cent(?:re|er)\b"),             # Nof HaGalil Center
    _c(r"\bat\s+the\s+[\w\s\-]{3,30}\s+cent(?:re|er)\b"),
]

# --- screenshot: TEXT MENTION ONLY, see the caveat above
SCREENSHOT = [
    _c(r"\bscreen\s*-?\s*shots?\b"),
    _c(r"\b(?:see|find)\s+(?:the\s+)?attach"),
    _c(r"\battach(?:ed|ment)s?\b"),
    _c(r"\bsnippet\b"),
    _c(r"\b(?:video|image|photo)\s+(?:is\s+)?attached\b"),
]

# --- card: first 6 and last 4, or a masked PAN
CARD = [
    _c(r"\b(?:first\s*)?6\s*[-\s]?digits?\s*[:\-]?\s*\d{6}\b"),
    _c(r"\blast\s*4\s*[-\s]?digits?\s*[:\-]?\s*\d{4}\b"),
    _c(r"\b\d{6}\s*\*+\s*\d{4}\b"),
    _c(r"\b\d{4}\s\d{2}\*{3,}\d{4}\b"),
]

# --- invoice reference: 4917/11916, 2852-2024-612INV, 5239_851STM, 1538-23450
INVOICE = [
    _c(r"\b\d{3,5}\s*[/_\-]\s*\d{2,6}(?:\s*[-_/]\s*\d{1,6})?\s*(?:INV|CN|STM|CSTM)?\b"),
    _c(r"\binvoice\s*(?:number|no|ref|#)\s*[:\-]?\s*\S+"),
    _c(r"\b(?:INV|CN|STM)\d{3,}\b"),
]

PAYMENT_CATS = ("Payments Registration", "Payments - Credit Card", "Payments - Direct Debit")
INVOICE_CATS = ("Invoicing", "SOA")


def _any(pats, text):
    return any(p.search(text) for p in pats)


def check(short_desc, description, category=None):
    """Missing items, as a list. 'screenshot (text)' is deliberately labelled to
    keep it visibly weaker than the rest -- it is a mention, not proof."""
    text = "%s\n%s" % (short_desc or "", description or "")
    missing = []
    if not _any(COMPANY, text):
        missing.append("company")
    if not _any(CENTRE, text):
        missing.append("centre")
    if not _any(SCREENSHOT, text):
        missing.append("screenshot (text)")
    if category in PAYMENT_CATS and not _any(CARD, text):
        missing.append("card 6+4")
    if category in INVOICE_CATS and not _any(INVOICE, text):
        missing.append("invoice number")
    return missing
